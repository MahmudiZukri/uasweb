<?php
include "koneksi.php";

$kode_produk    = $_POST['kode_produk'];
$nama_produk    = $_POST['nama_produk'];
$warna          = $_POST['warna'];
$merk           = $_POST['merk'];
$harga          = $_POST['harga'];

//skrip dsl insert
if (isset($_POST['tambah'])) {
    $sql = mysqli_query($koneksi, "INSERT INTO produk VALUES ( NULL, '$kode_produk', '$nama_produk', '$warna', '$merk', '$harga')");
    header('location:produk.php');
}
