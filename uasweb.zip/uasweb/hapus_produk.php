<?php

include "koneksi.php";
$id = $_GET['id'];

$sql = mysqli_query($koneksi, "DELETE FROM produk WHERE id='$id'");
header('location:produk.php');
