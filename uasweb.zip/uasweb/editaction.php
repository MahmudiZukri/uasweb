<?php

include "koneksi.php";

$id              = $_POST['id'];
$kode_produk     = $_POST['kode_produk'];
$nama_produk     = $_POST['nama_produk'];
$warna           = $_POST['warna'];
$merk            = $_POST['merk'];
$harga           = $_POST['harga'];

$sql = mysqli_query($koneksi, "UPDATE produk SET kode_produk='$kode_produk',
                                nama_produk='$nama_produk',
                                warna='$warna',
                                merk='$merk',
                                harga='$harga'
                                WHERE id=$id");
header('location:produk.php');
