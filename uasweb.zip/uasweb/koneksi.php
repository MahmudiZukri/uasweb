<?php

//deklarasi atribut server
$server        = "localhost";
$user          = "root";
$password      = "";
$db            = "uasweb";

//query connect MariaDB
$koneksi = mysqli_connect($server, $user, $password, $db);
if (mysqli_connect_error()) {
    trigger_error('Koneksi Gagal!');

    //menutup DB
    mysqli_close($koneksi);
}
